#!/bin/sh

# make zip file to upload chrome app store.
# > sh ./build.sh
zip life-new-tab *.html *.js *.css * png *.json