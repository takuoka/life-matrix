# ※ WIP



# life-matrix
Chrome extension of new-tab.

# Screen Shot (WIP)
<img src="https://raw.githubusercontent.com/entotsu/life-matrix/master/wip_screenshot.png">


# TODO
- [ ] ask birthday & lifespan
- [ ] improve design
- [ ] publish to chrome web app store
- [ ] custom color
- [ ] custom span
